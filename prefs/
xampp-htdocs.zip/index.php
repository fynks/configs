<?php
?>
<!DOCTYPE html><html><head><link rel="icon" href="./favicon.ico" type="image/x-icon"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>*{box-sizing:border-box;text-align:center;text-decoration:none; font-weight:200}svg{margin:auto}html{scroll-behavior:smooth}body{ margin:10% auto; font-family:'Courier New', Courier, monospace;padding:12px}a{ border:1px solid blueviolet; padding:6px; border-radius:4px;color:#524E31)}a:hover{ border:1px solid #2be277; color:red}</style><title>Local host | Blocked</title></head><body>
<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-alert-octagon" width="74" height="74" viewBox="0 0 24 24" stroke-width="1.5" stroke="#f0aa69" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <path d="M8.7 3h6.6c0.3 0 .5 .1 .7 .3l4.7 4.7c0.2 .2 .3 .4 .3 .7v6.6c0 .3 -.1 .5 -.3 .7l-4.7 4.7c-0.2 .2 -.4 .3 -.7 .3h-6.6c-0.3 0 -.5 -.1 -.7 -.3l-4.7 -4.7c-0.2 -.2 -.3 -.4 -.3 -.7v-6.6c0 -.3 .1 -.5 .3 -.7l4.7 -4.7c0.2 -.2 .4 -.3 .7 -.3z" />
  <line x1="12" y1="8" x2="12" y2="12" />
  <line x1="12" y1="16" x2="12.01" y2="16" />
</svg>
<h1>Blocked Website</h1>
<h3>This website has been blocked by the <code>Hosts</code> file.</h3>
<h3><a href=https://duckduckgo.com/?q=free+proxy>Proxy</a>
<a href=http://127.0.0.1/ftp>File manager</a></h3>
</body></html>

